package com.abdulrahman.lanscanner;

import android.os.Bundle;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.LinkProperties;
import android.net.LinkAddress;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private TextView networkInfo, status, results;
    private Button scanButton;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        networkInfo = findViewById(R.id.networkInfo);
        status = findViewById(R.id.status);
        results = findViewById(R.id.results);
        scanButton = findViewById(R.id.scanButton);

        showNetworkInfo();
        scanButton.setOnClickListener(v -> startScan());
    }

    private String getLocalIp() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        Network active = cm.getActiveNetwork();
        if (active == null) return null;
        LinkProperties lp = cm.getLinkProperties(active);
        if (lp == null) return null;
        for (LinkAddress la : lp.getLinkAddresses()) {
            InetAddress addr = la.getAddress();
            if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                return addr.getHostAddress();
            }
        }
        return null;
    }

    private void showNetworkInfo() {
        String ip = getLocalIp();
        networkInfo.setText(ip == null ? "لا يوجد اتصال شبكة متاح" : "عنوان جهازك على الشبكة: " + ip);
    }

    private void startScan() {
        String ip = getLocalIp();
        if (ip == null) {
            status.setText("تعذر العثور على عنوان IP");
            return;
        }
        scanButton.setEnabled(false);
        results.setText("");
        status.setText("جارٍ الفحص...");

        executor.execute(() -> {
            String[] p = ip.split("\\.");
            if (p.length != 4) {
                runOnUiThread(() -> {
                    status.setText("عنوان الشبكة غير صالح");
                    scanButton.setEnabled(true);
                });
                return;
            }
            String prefix = p[0] + "." + p[1] + "." + p[2] + ".";
            List<String> found = new ArrayList<>();

            for (int i = 1; i <= 254; i++) {
                String host = prefix + i;
                try {
                    InetAddress address = InetAddress.getByName(host);
                    if (address.isReachable(250)) {
                        found.add("✓ " + host + (host.equals(ip) ? " (هذا الجهاز)" : ""));
                    }
                } catch (Exception ignored) {}
            }

            runOnUiThread(() -> {
                if (found.isEmpty()) {
                    results.setText("لم يتم العثور على أجهزة تستجيب للفحص.");
                } else {
                    results.setText(String.join("\n", found));
                }
                status.setText("انتهى الفحص: تم العثور على " + found.size() + " جهاز/أجهزة");
                scanButton.setEnabled(true);
            });
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
